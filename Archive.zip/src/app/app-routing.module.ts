import { DeleteProductComponent } from './products/delete-product/delete-product.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './products/product-list/product-list.component';
import { CreateProductComponent } from './products/create-product/create-product.component';


const routes: Routes = [
  { path: '', component: ProductListComponent },
  { path: 'create', component: CreateProductComponent },
  { path: 'edit/:id', component: CreateProductComponent },
  { path: 'delete/:id', component: DeleteProductComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

