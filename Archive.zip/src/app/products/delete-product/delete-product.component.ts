import { Product } from '../product.model';
import { NgForm } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../../services/products.service';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-delete-product',
  templateUrl: './delete-product.component.html',
  styleUrls: ['./delete-product.component.css']
})
export class DeleteProductComponent implements OnInit {
  private mode = 'delete';
  private productId: string;
  product: Product;
  canDelete = false;

  constructor(public productService: ProductsService, public route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('id')) {
        this.productId = paramMap.get('id');
        this.productService.getProduct(this.productId)
          .subscribe((product) => {
            this.product = product;
            console.log(this.productId);
            if (this.product.quantity === 1) {
              this.canDelete = true;
            }

          });
      }

    });
  }
  ondeleteProduct() {
    if (this.canDelete) {
      this.productService.deleteProduct(this.product._id);
    }
  }
}
