import { Product } from '../product.model';
import { NgForm } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../../services/products.service';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-create-product',
  templateUrl: './create-product.component.html',
  styleUrls: ['./create-product.component.css']
})
export class CreateProductComponent implements OnInit {
  private mode = 'create';
  private productId: string;
  product: Product;
  constructor(public productService: ProductsService, public route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('id')) {
        this.productId = paramMap.get('id');
        this.mode = 'edit';
        this.productService.getProduct(this.productId)
          .subscribe((product) => {
            this.product = product;
          });

      } else {
        this.mode = 'create';
      }

    });
  }
  onCreateProduct(form: NgForm) {
    if (form.invalid) {
      return;
    }
    if (this.mode === 'create') {
      const newProduct: Product = {
        name: form.value.name,
        quantity: form.value.quantity,
        price: form.value.price
      };
      console.log(newProduct);
      this.productService.addProduct(newProduct);
    } else {
      this.productService.updateProduct({
        _id: this.product._id,
        name: form.value.name,
        quantity: form.value.quantity,
        price: form.value.price
      });
    }
    form.resetForm();

  }
  onFormReset(form: NgForm) {
    form.resetForm();
  }

}
