export interface Product {
  _id?: string;
  name: string;
  quantity: number;
  date?: Date;
  price: number;
}
