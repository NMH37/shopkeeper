const Product = require('./../models/product');

exports.fetchProducts = (req, res) => {
  Product.find()
    .then((documents) => {
      res.status(200).json({
        Products: documents,
        message: 'Product Fetched from DB'
      });
    })
    .catch(() => {
      res.status(500).json({ message: 'Fetching Products failed !' })
    });
}
exports.createProduct = (req, res) => {
  console.log(req.body)
  product = new Product({
    name: req.body.name,
    quantity: req.body.quantity,
    price: req.body.price
  });
  product.save().then((product) => {
    res.status(201).json(product);
  })
    .catch(error => {
      res.status(500).json({ message: 'Creating a new Product failed' })
    });
}

exports.getOneProduct = (req, res) => {
  Product.findOne({ _id: req.params.id })
    .then((product) => {
      if (product) {
        res.status(200).json(product);

      } else {
        res.status(401).json({ message: 'Product not found' })
      }
    })
    .catch(() => {
      res.status(500).json({ message: 'Fetching Product failed !' })
    });
}

exports.updateProduct = (req, res) => {
  Product.updateOne({ _id: req.params.id }, req.body, { new: true }).then((result) => {

    if (result.nModified > 0) {
      res.status(200).json({ message: ' updated one' });
    } else {
      res.status(401).json({ message: 'Not Authorized to Update' })
    }

  })
    .catch((error) => {
      res.status(500).json({ message: "Product can't be updated" })
    })
}
exports.removeProduct = (req, res) => {
  Product.deleteOne({ _id: req.params.id, quantity: 1 })
    .then((response) => {
      console.log(response, 'checking delete method')
      if (response.n > 0) {
        res.status(200).json({ message: 'Product deleted' });
      } else {
        res.status(401).json({ message: 'To delete a Product Quantity has to be zero' })
      }

    })
    .catch(() => {
      res.status(500).json({ message: 'Deleting Product failed !' });
    });

}
