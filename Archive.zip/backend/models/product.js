const mongoose = require('mongoose');

const productSchema = mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Enter Product name!'],
    min: 3,
    trim: true
  },
  quantity: {
    type: Number,
    required: [true, 'Enter Quantity, it has to be atleast 1!'],
    min: 1,
    trim: true
  },
  date: {
    type: Date,
    default: Date.now
  },
  price: {
    type: Number,
    required: [true, 'Enter Price has to be atleast $1 !'],
    min: 1,
    trim: true
  }
}, { timestamps: true });

module.exports = mongoose.model('product', productSchema);
